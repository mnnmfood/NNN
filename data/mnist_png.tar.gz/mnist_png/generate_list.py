import os
import glob
import numpy as np
parentDirs = list(filter(os.path.isdir, os.listdir("./")))
print(os.listdir("./"))
for pdir in parentDirs:
    childnames = os.listdir(pdir)
    print(childnames)
    for child in childnames:
        path = pdir + "/" + child
        if os.path.isdir(path):
            reg = path + "/*.png"
            images = glob.glob(reg)
            images = [st.split("\\")[-1] for st in images] 
            np.savetxt(path + "/index.csv", images, fmt="%s")
    #print(childDirs)
    